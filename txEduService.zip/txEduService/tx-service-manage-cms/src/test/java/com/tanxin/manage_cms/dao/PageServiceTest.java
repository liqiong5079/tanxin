package com.tanxin.manage_cms.dao;

import com.tanxin.framework.domain.cms.CmsPage;
import com.tanxin.framework.domain.cms.CmsPageParam;
import com.tanxin.manage_cms.service.PageService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * @author Administrator
 * @version 1.0
 * @create 2018-09-12 18:11
 **/
@SpringBootTest
@RunWith(SpringRunner.class)
public class PageServiceTest {

    @Autowired
    PageService pageService;

    @Test
    public void getPageHtml(){
        String html = pageService.getPageHtml("5facea73b5fd4538f4bd5fab");
        System.out.println(html);
    }

}

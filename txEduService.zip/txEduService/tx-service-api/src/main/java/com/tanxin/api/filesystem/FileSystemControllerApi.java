package com.tanxin.api.filesystem;

import com.tanxin.framework.domain.course.ext.CategoryNode;
import com.tanxin.framework.domain.filesystem.response.UploadFileResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.multipart.MultipartFile;

@Api(value = "文件分类管理",description = "文件分类管理",tags = {"文件分类管理"})
public interface FileSystemControllerApi {
    //上传文件
    @ApiOperation("上传文件接口")
    public UploadFileResult  upload(MultipartFile multipartFile,
                                    String filetag,
                                    String businesskey,
                                    String metadata);
}

package com.tanxin.test.rabbitmq;

import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

public class Producer03_routing {

    //队列名称
    private static final String QUEUE_INFORM_EMAIL = "queue_inform_email";
    private static final String QUEUE_INFORM_SMS = "queue_inform_sms";
    private static final String EXCHANGE_ROUTING_INFORM="exchange_routing_inform";
    private static final String ROUTINGKEY_EMAIL="info_email";
    private static final String ROUTINGKEY_SMS="info_sms";

    public static void main(String[] args) {
        //通过连接工厂创建连接和mq连接
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost("localhost");
        connectionFactory.setPort(5672);//端口号
        connectionFactory.setUsername("guest");
        connectionFactory.setPassword("guest");
        //设置虚拟机,一个mq可以设置多个虚拟机，每个虚拟机就相当于一个独立的mq
        connectionFactory.setVirtualHost("/");
        //建立新连接
        Connection connection = null;
        Channel channel = null;
        try {
            //创建新连接
            connection = connectionFactory.newConnection();
            //创建会话通道,生产者和mq服务所有通信都在channel中完成
            channel = connection.createChannel();
            //声明队列,如果队列中没有则要创建
            //参数：String queue, boolean durable, boolean exclusive, boolean autoDelete, Map<String,Object> arguments
            /**
             * 1.queue：队列名称
             * 2.durable：是否持久化，如果持久化，mq重启后队列还存在
             * 3.exclusive： 是否独占连接，队列只允许在该连接中访问，如果连接关闭队列自动删除，如果将此参数设置true可用于临时队列的创建
             * 4.autoDelete：自动删除，队列不再使用时是否自动删除次队列，如果将此参数和exclusive参数设置为true就可以实现临时队列（队列不用了就自动删除）
             * 5.arguments：参数，可以设置队列的扩展参数，比如：可以设置存活时间
             */
            channel.queueDeclare(QUEUE_INFORM_EMAIL,true,false,false,null);
            channel.queueDeclare(QUEUE_INFORM_SMS,true,false,false,null);
            //声明交换机
            //参数：String exchange, BuiltinExchangeType type
            /**
             * 参数明细
             * 1.exchange：交换机名称
             * 2.type：交换机类型
             *  fanout：对应的rabbitmq的工作模式是publish/subscribe
             *  direct：对应Routing的工作模式
             *  topic：对应topic的工作模式
             *  headers：对应headers的工作模式
             */
            channel.exchangeDeclare(EXCHANGE_ROUTING_INFORM, BuiltinExchangeType.DIRECT);
            //进行交换机和队列进行绑定
            //参数：String queue, String exchange, java.lang.String routingKey
            /**
             * 参数明细：
             * 1.queue 队列名称
             * 2.exchange 交换机名称
             * 3.routingKey 路由key，作用是交换机根据路由key的值将消息转发到指定的队列中，在发布订阅模式中设置为控制符串
             */
            channel.queueBind(QUEUE_INFORM_EMAIL,EXCHANGE_ROUTING_INFORM,ROUTINGKEY_EMAIL);
            channel.queueBind(QUEUE_INFORM_SMS,EXCHANGE_ROUTING_INFORM,ROUTINGKEY_SMS);
            //发送消息
            //参数：String exchange, String routingKey, com.rabbitmq.client.AMQP.BasicProperties props, byte[] body
            /**
             *参数明细：
             * 1.exchange：交换机，如果不指定将使用mq默认的交换机,设置为“”
             * 2.routingKey：路由key，交换机根据路由key来将消息转发到指定的队列，如果使用默认交换机，routingKey设置为队列名称
             * 3.props：消息的属性
             * 4.body：消息内容
             */
            //消息内容
            for (int i=0;i<5;i++){
                //发消息的时候指定routingKey
                String message = "send email inform message to user";
                channel.basicPublish(EXCHANGE_ROUTING_INFORM,ROUTINGKEY_EMAIL,null,message.getBytes());
                System.out.println("send mq to "+message);
            }
            for (int i=0;i<5;i++){
                //发消息的时候指定routingKey
                String message = "send email inform message to user";
                channel.basicPublish(EXCHANGE_ROUTING_INFORM,ROUTINGKEY_SMS,null,message.getBytes());
                System.out.println("send mq to "+message);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭连接
            //先关闭通道
            try {
                channel.close();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (TimeoutException e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}

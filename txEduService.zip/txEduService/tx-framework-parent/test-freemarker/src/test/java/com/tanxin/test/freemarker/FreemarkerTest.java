package com.tanxin.test.freemarker;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.security.auth.login.Configuration;

@SpringBootTest
@RunWith(SpringRunner.class)
public class FreemarkerTest {

    //测试静态化，基于ftl模板文件生成HTML文件
    @Test
    public void testGenerateHtml(){
        //定义配置类
        //Configuration configuration = new Configuration(Configuration.);
    }

}

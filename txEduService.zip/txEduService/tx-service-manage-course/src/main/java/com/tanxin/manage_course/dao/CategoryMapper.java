package com.tanxin.manage_course.dao;

import com.tanxin.framework.domain.course.ext.CategoryNode;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CategoryMapper {
    //查询分类
    CategoryNode selectList();
}

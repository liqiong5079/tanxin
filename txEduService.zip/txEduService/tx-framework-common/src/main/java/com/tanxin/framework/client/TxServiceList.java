package com.tanxin.framework.client;


public class TxServiceList {
    public static final String TX_GOVERN_CENTER = "tx-govern-center";
    public static final String TX_SERVICE_PORTALVIEW = "tx-service-portalview";
    public static final String TX_SERVICE_SEARCH = "tx-service-search";
    public static final String TX_SERVICE_MANAGE_COURSE = "tx-service-manage-course";
    public static final String TX_SERVICE_MANAGE_MEDIA = "tx-service-manage-media";
    public static final String TX_SERVICE_MANAGE_CMS = "tx-service-manage-cms";
    public static final String TX_SERVICE_UCENTER = "tx-service-ucenter";
    public static final String TX_SERVICE_UCENTER_AUTH = "tx-service-ucenter-auth";
    public static final String TX_SERVICE_UCENTER_JWT = "tx-service-ucenter-jwt";
    public static final String TX_SERVICE_BASE_FILESYSTEM = "tx-service-base-filesystem";
    public static final String TX_GOVERN_GATEWAY = "tx-govern-gateway";
    public static final String TX_SERVICE_BASE_ID = "tx-service-base-id";
    public static final String TX_SERVICE_MANAGE_ORDER = "tx-service-manage-order";
    public static final String TX_SERVICE_LEARNING = "tx-service-learning";

}
